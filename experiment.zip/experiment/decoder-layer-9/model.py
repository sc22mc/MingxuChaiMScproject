# Copyright (c) Microsoft Corporation. 
# Licensed under the MIT license.

import torch
import torch.nn as nn
import torch
from torch.autograd import Variable
import copy


class Seq2Seq(nn.Module):

    def __init__(self, encoder, decoder, config, beam_size=None, max_length=None, sos_id=None, eos_id=None):
        super(Seq2Seq, self).__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.config = config
        '''
        buffer通常用于构造一个参数不变的缓冲区
        生成了一个2048x2048的下三角矩阵，其中对角线以下的元素都为1，对角线及以上的元素都为0。
        这个矩阵在模型中被用作一个bias，用于在生成序列时限制模型只能参考当前位置之前的token。
        将一个固定的下三角矩阵注册为模型的buffer，实际上是一个参数不变（不需要梯度）的掩码器，命名为bias？
        生成第i个时只能看到i-1及之前（模拟真实情况，防止看到未来的信息）和已经输出的部分
        '''
        self.register_buffer("bias", torch.tril(torch.ones(2048, 2048)))
        # dense和lm_head都是全连接层，lsm是log softmax层

        # 把输入的特征向量映射到另一组特征向量（不改变特征尺寸，只提取特征）
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        # 把特征向量映射到词汇表大小的特征向量，方便softmax输出概率
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        # 输出概率分布，dim=-1沿着最后一个维度进行归一化，最后一个维度在多分类代表类别，使概率和为1
        self.lsm = nn.LogSoftmax(dim=-1)
        # 将模型中的encoder里词嵌入和decoder之后lm_head的权重参数绑定在一起，以便在训练过程中共享权重，减少模型参数的数量。
        self.tie_weights()
        # beam搜索的相关信息
        self.beam_size = beam_size
        # target
        self.max_length = max_length
        self.sos_id = sos_id
        self.eos_id = eos_id

    '''
    Both functions are used to realize parameter sharing
    '''

    # 将模型中的权重绑定在一起，以便在训练过程中共享权重。这个方法通常用于自然语言处理中的语言模型，以减少模型参数的数量。
    # copy the parameter of second_module to first_module
    def _tie_or_clone_weights(self, first_module, second_module):
        """ Tie or clone module weights depending of weither we are using TorchScript or not
        """
        # TorchScript 是一种用于创建可序列化和可优化的 PyTorch 模型的方法。如果使用了不能直接共享需要克隆
        if self.config.torchscript:
            first_module.weight = nn.Parameter(second_module.weight.clone())
        else:
            first_module.weight = second_module.weight

    def tie_weights(self):
        """ Make sure we are sharing the input and output embeddings.
            Export to TorchScript can't handle parameter sharing so we are cloning them instead.
        """
        # self.encoder.embeddings.word_embeddings在encoder里面，用于从单词索引提取出语义向量
        # lm_head在decoder之后，用于把语义向量重新转换会单词索引
        # 它们可以共享一个权重参数
        self._tie_or_clone_weights(self.lm_head,
                                   self.encoder.embeddings.word_embeddings)

    def forward(self, source_ids=None, source_mask=None, target_ids=None, target_mask=None, args=None):
        # CodeBERT接收ids和mask两个参数进行编码，提取有用的信息返回一个向量

        # source_ids和source_mask形状为（batch_size,source_length）
        # outputs是一个元组不仅又最后一层的hidden，还有别的信息
        outputs = self.encoder(source_ids, attention_mask=source_mask)

        # outputs[0]形状为（batch_size,source_length,hidden_size）
        # outputs[0]表示我们只关注output元组中最后一层所有批次的隐藏状态
        # permute交换维度位置，但会使其在内存上不连续，因此需要用contiguous()使其连续方便其使用view等操作
        # 形状变为(seq_length, batch_size, hidden_size)
        encoder_output = outputs[0].permute([1, 0, 2]).contiguous()

        # 有target就是训练模式，生成target mask，计算loss
        # target_ids包含batch_size个target_id,所以形状为（batch_size,target_length）
        # 所以target_ids.shape[1]是target的长度
        if target_ids is not None:
            # bias为（2048*2048），[:target_ids.shape[1], :target_ids.shape[1]]从bias截取一个尺寸一样的
            # 1-是为了翻转
            # -1e4是为了在后续计算softmax时，被mask掉的位置的值接近于0（因为e的-1e4次方接近于0）
            # 训练模式传入decoder的是encoder的所有hidden和target，所以需要根据target构建一个三角矩阵
            attn_mask = -1e4 * (1 - self.bias[:target_ids.shape[1], :target_ids.shape[1]])

            # 在Transformer模型中，encoder和decoder共用 .embeddings 是基本组成部分，
            # encoder.embedding用于将输入target的token（通常是词或字的索引）转换为连续的向量表示，这些向量表示被模型用于进一步的处理。
            # 嵌入层的参数通常是随机初始化的，然后在训练过程中，这些参数会被更新。
            # target_ids的形状为（batch_size,target_length）经embeddings处理后tgt_embeddings的形状变为（batch_size, sequence_length, embedding_size）
            # 再进行permute操作形状变为(seq_length, batch_size, hidden_size)
            tgt_embeddings = self.encoder.embeddings(target_ids).permute([1, 0, 2]).contiguous()

            # out形状为(target_length, batch_size, hidden_size)
            out = self.decoder(tgt_embeddings, encoder_output, tgt_mask=attn_mask,
                               memory_key_padding_mask=(1 - source_mask).bool())
            print("Shape of 'out' after permute and contiguous: ", out.shape)
            # Shape of 'out' after permute and contiguous:  torch.Size([4, 256, 768])








            # dense的作用是调整每个batch每个target的token的hidden_state维度
            # 将经过线性层的输出通过激活函数tanh处理。tanh是一种常见的激活函数，它可以将输入值压缩到-1和1之间。
            # 使输出范围更加稳定，只改变每个hidden的值但不改变hidden的维度
            # 经过permute处理形状变为(batch_size, target_length, new_hidden_size)
            hidden_states = torch.tanh(self.dense(out)).permute([1, 0, 2]).contiguous()

            # 调整到词汇表尺寸
            # 形状为(batch_size, target_length, new_new_hidden_size)
            lm_logits = self.lm_head(hidden_states)

            # 创建一个布尔型张量，标识了计算损失时都应该考虑哪些tokens
            # target_mask形状为（batch_size，target_length）
            # [...]选择所有未指定的维度，这里只选择除了target_length外所有维度
            # target_length这个维度从[1:]第二个开始选择,因为第一个维度时起始符号
            # ne(0) 就是创建一个新的布尔型张量，该张量与 target_mask[..., 1:] 有相同的形状，其中的每个元素都表示 target_mask[..., 1:] 中对应元素是否不等于 0，[T,T,T,T,F,F,F,F]
            # view(-1)把（batch_size,target_length）变为（batch_size*target_length,）一维的
            # 因为像交叉熵函数只接受一维输入
            active_loss = target_mask[..., 1:].ne(0).view(-1) == 1

            # 将输出向左移动一位，也就是说，第n个位置的输出现在用来预测第n+1个位置的单词。
            shift_logits = lm_logits[..., :-1, :].contiguous()
            # 这行代码将目标ID向右移动一位，以与shift_logits对应。这样，第n个位置的shift_logits就对应着第n+1个位置的词。
            shift_labels = target_ids[..., 1:].contiguous()
            # Flatten the tokens
            # 这一行定义了损失函数为交叉熵损失（CrossEntropyLoss）。ignore_index=-1参数表示对标签值为-1的项不计算损失。
            loss_fct = nn.CrossEntropyLoss(ignore_index=-1)
            # 这行代码用来计算模型的预测（shift_logits）与真实标签（shift_labels）之间的损失。
            loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1))[active_loss],
                            shift_labels.view(-1)[active_loss])
            # 这一行将单个样本的损失，总损失（单个样本损失乘以损失位置的数量）和损失位置的数量封装成一个元组返回。
            outputs = loss, loss * active_loss.sum(), active_loss.sum()
            return outputs
        else:
            # 如果没有传入target_ids和target_mask就是Predict
            preds = []

            # 创建了一个填充值为0的长整型张量（长度为1）。
            zero = torch.cuda.LongTensor(1).fill_(0)

            # source_ids为（batch_size, sequence_length）
            # 所以这是逐个处理该batch的每个序列(一次处理一个序列)
            for i in range(source_ids.shape[0]):

                # (seq_length, batch_size, hidden_size)变为(seq_length, 第i个, hidden_size)
                # 也是为了逐个处理每个batch_size
                context = encoder_output[:, i:i + 1]

                # 选取改batch第 i个mask，结果是一个形状为 (第i个, source_sequence_length)
                context_mask = source_mask[i:i + 1, :]

                beam = Beam(self.beam_size, self.sos_id, self.eos_id)

                # 返回beam_size个可能target_id在词汇表的id值
                # 例如 beam size 是 3，且当前时间步预测的词的 id 是 [4, 5, 6]
                # 则返回tensor([[4],
                #              [5],
                #              [6]])
                # 形状为[beam_size, 1]
                input_ids = beam.getCurrentState()

                # repeat 函数在 PyTorch 中用来复制 tensor
                # repeat 1表示不变
                # repeat 后形状变为(seq_length, 10, hidden_size)
                # 这样，原本只针对一个单一上下文进行预测的 decoder，现在对同一个上下文有了 10 个并行的 "拷贝"，每一个 "拷贝" 可以产生一个独立的预测结果，用于实现 beam search 中的多路径搜索。
                context = context.repeat(1, self.beam_size, 1)

                # (1, source_sequence_length)变为(10, source_sequence_length)
                context_mask = context_mask.repeat(self.beam_size, 1)

                # self.maxlengt指的是最大生成序列128个
                for _ in range(self.max_length):
                    # 调用done判断是否结束
                    if beam.done():
                        break

                    # 预测模式，只是为了让encoder有东西可接收
                    attn_mask = -1e4 * (1 - self.bias[:input_ids.shape[1], :input_ids.shape[1]])

                    # encoder.embeddings用于把token转为embedding
                    # [beam_size, 1, embedding_dim]
                    # 再进行permute操作形状变为[1, beam_size, embedding_dim]
                    tgt_embeddings = self.encoder.embeddings(input_ids).permute([1, 0, 2]).contiguous()

                    # tgt_embeddings为现有预测出注释token的张量
                    # context为encoder处理code输出转换后的(seq_length, beam_size, hidden_size)
                    # memory_key_padding_mask（等于(1 - context_mask).bool()）：这个是源代码序列的掩码，用来防止模型将源代码中的padding部分考虑进来








                    out = self.decoder(tgt_embeddings, context, tgt_mask=attn_mask,
                                       memory_key_padding_mask=(1 - context_mask).bool())


                    # out仍为[1, beam_size, hs?]，tanh是把值压缩不改变形状
                    out = torch.tanh(self.dense(out))
                    # 处理后为[beam_size, hs?]
                    hidden_states = out.permute([1, 0, 2]).contiguous()[:, -1, :]

                    # .data用于获取张量数值
                    # 获取模型对每个可能的下一个词的概率分布，但是我们并不希望这个概率分布在之后的计算中被求梯度，因为这个概率分布是用来给beam search选择下一个词的，我们只需要其数值，而不需要其计算历史和梯度。
                    out = self.lsm(self.lm_head(hidden_states)).data
                    # 根据接收到out更新beam
                    beam.advance(out)
                    # 这两行代码的目的是更新模型的输入，以便在下一步能够基于当前选择的beam和词汇进行预测
                    input_ids.data.copy_(input_ids.data.index_select(0, beam.getCurrentOrigin()))
                    input_ids = torch.cat((input_ids, beam.getCurrentState()), -1)
                # 获取beam search的结果，并进行处理，然后添加到preds列表中
                hyp = beam.getHyp(beam.getFinal())
                pred = beam.buildTargetTokens(hyp)[:self.beam_size]
                pred = [torch.cat([x.view(-1) for x in p] + [zero] * (self.max_length - len(p))).view(1, -1) for p in
                        pred]
                preds.append(torch.cat(pred, 0).unsqueeze(0))
            # 这里的preds是一个列表，列表中每个元素是一个tensor，这些tensor代表了模型对不同输入的预测结果。因为模型是分批次处理输入的，所以每个tensor对应一个批次的结果。
            # torch.cat(preds, 0)的作用就是把这些tensor按照第0维（通常是批次维度）拼接在一起，得到一个新的tensor。这样，新的tensor就包含了模型对所有输入的预测结果
            preds = torch.cat(preds, 0)
            return preds


class Beam(object):
    def __init__(self, size, sos, eos):
        self.size = size
        self.tt = torch.cuda
        # The score for each translation on the beam.
        self.scores = self.tt.FloatTensor(size).zero_()
        # The backpointers at each time-step.
        self.prevKs = []
        # The outputs at each time-step.
        self.nextYs = [self.tt.LongTensor(size)
                       .fill_(0)]
        self.nextYs[0][0] = sos
        # Has EOS topped the beam yet.
        self._eos = eos
        self.eosTop = False
        # Time and k pair for finished.
        self.finished = []

    def getCurrentState(self):
        "Get the outputs for the current timestep."
        batch = self.tt.LongTensor(self.nextYs[-1]).view(-1, 1)
        return batch

    def getCurrentOrigin(self):
        "Get the backpointers for the current timestep."
        return self.prevKs[-1]

    def advance(self, wordLk):
        """
        Given prob over words for every last beam `wordLk` and attention
        `attnOut`: Compute and update the beam search.

        Parameters:

        * `wordLk`- probs of advancing from the last step (K x words)
        * `attnOut`- attention at the last step

        Returns: True if beam search is complete.
        """
        numWords = wordLk.size(1)

        # Sum the previous scores.
        if len(self.prevKs) > 0:
            beamLk = wordLk + self.scores.unsqueeze(1).expand_as(wordLk)

            # Don't let EOS have children.
            for i in range(self.nextYs[-1].size(0)):
                if self.nextYs[-1][i] == self._eos:
                    beamLk[i] = -1e20
        else:
            beamLk = wordLk[0]
        flatBeamLk = beamLk.view(-1)
        bestScores, bestScoresId = flatBeamLk.topk(self.size, 0, True, True)

        self.scores = bestScores

        # bestScoresId is flattened beam x word array, so calculate which
        # word and beam each score came from
        prevK = bestScoresId // numWords
        self.prevKs.append(prevK)
        self.nextYs.append((bestScoresId - prevK * numWords))

        for i in range(self.nextYs[-1].size(0)):
            if self.nextYs[-1][i] == self._eos:
                s = self.scores[i]
                self.finished.append((s, len(self.nextYs) - 1, i))

        # End condition is when top-of-beam is EOS and no global score.
        if self.nextYs[-1][0] == self._eos:
            self.eosTop = True

    def done(self):
        return self.eosTop and len(self.finished) >= self.size

    def getFinal(self):
        if len(self.finished) == 0:
            self.finished.append((self.scores[0], len(self.nextYs) - 1, 0))
        self.finished.sort(key=lambda a: -a[0])
        if len(self.finished) != self.size:
            unfinished = []
            for i in range(self.nextYs[-1].size(0)):
                if self.nextYs[-1][i] != self._eos:
                    s = self.scores[i]
                    unfinished.append((s, len(self.nextYs) - 1, i))
            unfinished.sort(key=lambda a: -a[0])
            self.finished += unfinished[:self.size - len(self.finished)]
        return self.finished[:self.size]

    def getHyp(self, beam_res):
        """
        Walk back to construct the full hypothesis.
        """
        hyps = []
        for _, timestep, k in beam_res:
            hyp = []
            for j in range(len(self.prevKs[:timestep]) - 1, -1, -1):
                hyp.append(self.nextYs[j + 1][k])
                k = self.prevKs[j][k]
            hyps.append(hyp[::-1])
        return hyps

    def buildTargetTokens(self, preds):
        sentence = []
        for pred in preds:
            tokens = []
            for tok in pred:
                if tok == self._eos:
                    break
                tokens.append(tok)
            sentence.append(tokens)
        return sentence



