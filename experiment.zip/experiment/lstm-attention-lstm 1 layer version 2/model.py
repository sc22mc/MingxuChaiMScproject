# Copyright (c) Microsoft Corporation. 
# Licensed under the MIT license.

import torch
import torch.nn as nn
import torch
from torch.autograd import Variable
import copy

# 这里的hidden为传入的decoder_hidden[i]表示(batch_size, hidden_size)
# encoder_outputs表示(batch_size, sequence_length, hidden_size)

class Attention(nn.Module):
    def __init__(self, hidden_dim):
        super(Attention, self).__init__()
        self.hidden_dim = hidden_dim
        self.attention = nn.Linear(hidden_dim * 2, hidden_dim)
        self.v = nn.Parameter(torch.rand(hidden_dim))

    # hidden:(batch_size, hidden_size)
    # encoder_outputs:(batch_size, sequence_length, hidden_size)
    def forward(self, hidden, encoder_outputs):
        # 或取encoder_outputs的序列步长，
        timestep = encoder_outputs.shape[1]

        # if hidden is [batch_size, hidden_dim]
        # 如果2维小于3维
        if hidden.dim() < encoder_outputs.dim():
            # 把hidden在[1]这个维度上扩展timestep倍，方便和encoder_outputs计算score
            h = hidden.unsqueeze(1).expand(-1, timestep, -1)
        else:  # if hidden is [batch_size, timestep, hidden_dim]
            h = hidden

        attn_energies = self.score(h, encoder_outputs)
        # [batch_size, 1, timestep]
        return nn.functional.softmax(attn_energies, dim=1).unsqueeze(1)

    def score(self, hidden, encoder_outputs):
        # 先用cat在[2]上拼接，使其变为[batch_size, timestep, hidden_dim * 2]
        # 再用attention层变回[batch_size, timestep, hidden_dim]
        energy = torch.tanh(self.attention(torch.cat([hidden, encoder_outputs], 2)))
        # [batch_size, hidden_dim, timestep]
        energy = energy.transpose(1, 2)  # [B*H*T]
        # v为 [batch_size, 1, hidden_dim]
        # v再被压缩为[batch_size, timestep]
        v = self.v.repeat(encoder_outputs.shape[0], 1).unsqueeze(1)  # [B*1*H]
        energy = torch.bmm(v, energy)  # [B*1*T]
        return energy.squeeze(1)  # [B*T]


class Seq2Seq(nn.Module):

    def __init__(self, embedder, encoder, decoder, config, beam_size=None, max_length=None,seq_length=None,batch_size=None, sos_id=None, eos_id=None):
        super(Seq2Seq, self).__init__()
        self.embedder = embedder
        self.encoder = encoder
        self.decoder = decoder
        self.config = config

        self.hidden_dim = config.hidden_size
        self.attention = Attention(self.hidden_dim)
        # 把输入的特征向量映射到另一组特征向量（不改变特征尺寸，只进行线性变换
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        # 添加一个新的线性层缩小一倍
        self.input_projection = nn.Linear(self.hidden_dim * 2, self.hidden_dim) # 新增的代码
        # 把特征向量映射到词汇表大小的特征向量，方便softmax输出概率
        self.lm_head = nn.Linear(self.hidden_dim, config.vocab_size, bias=False)
        # 输出概率分布，dim=-1沿着最后一个维度进行归一化，最后一个维度在多分类代表类别，使概率和为1
        self.lsm = nn.LogSoftmax(dim=-1)
        # 将模型中的encoder里词嵌入和decoder之后lm_head的权重参数绑定在一起，以便在训练过程中共享权重，减少模型参数的数量。
        # beam搜索的相关信息
        self.beam_size = beam_size
        # target
        self.max_length = max_length
        self.seq_length = seq_length
        self.batch_size = batch_size
        self.sos_id = sos_id
        self.eos_id = eos_id

    def forward(self, source_ids=None, source_mask=None, target_ids=None, target_mask=None, **kwargs):
        input_embeddings = self.embedder.embeddings(source_ids)
        # last_hidden_state取输入id在最后一层的隐藏状态
        #input_embeddings = embeddings.last_hidden_state

        # (hidden, cell)：这是网络在最后一个时间步的隐藏状态和细胞状态，
        # 两者的形状都是(num_layers * num_directions, batch_size, hidden_size)
        # (1, batch_size, hidden_size)
        # encoder_outputs设置了batch_first=True这是网络在每个时间步的输出，形状通常为 (batch_size, sequence_length, hidden_size)
        encoder_outputs, (hidden, cell) = self.encoder(input_embeddings)

        if target_ids is not None:
            # Training
            # 获取当前batch所有target_id的第一个token，并重新恢复成2维的
            decoder_input = target_ids[:, 0].unsqueeze(1)
            outputs = []
            # 使用encoder和（h，c）初始化decoder的（h，c）
            # (1, batch_size, hidden_size)
            decoder_hidden = hidden
            decoder_cell = cell

            # target_ids.size(1)为128
            # 逐个（这里的逐个实际上是每次处理batch个）处理，因为target也是逐个生成的
            # a---
            # b---
            # c---
            # d---
            # 每次在整个batch沿着target_length处理
            for t in range(0, target_ids.size(1)):
                # Attention
                context = []
                # 编码器如果多层多向，那么需要多次提取
                for i in range(hidden.size(0)):
                    # hidden[i]表示(batch_size, hidden_size)
                    # encoder_outputs表示(batch_size, sequence_length, hidden_size)
                    # attention_weights为[batch_size, 1, timestep]
                    # 使用编码器最后一个时间步的隐藏状态作为decoder
                    attention_weights = self.attention(decoder_hidden[i], encoder_outputs)

                    # 这个上下文向量是编码器的所有输出的加权和（依据上一步decoder和encoder_outputs算出的注意力权重得来）
                    # 形状为[batch_size, 1, hidden_size]
                    context_layer = attention_weights.bmm(encoder_outputs)  # [B,1,H]
                    # 每层获取的上下文向量都添加在这里
                    context.append(context_layer)
                # 将所有 LSTM 层的上下文向量合并在一起
                # 形状为[batch_size, 1, hidden_size]
                context = torch.mean(torch.stack(context), dim=0)  # Use mean of contexts from all layers
                # 选取该batch所有序列第t个token
                # [batch_size, 1]
                decoder_input = target_ids[:, t].unsqueeze(1)
                # [batch_size, 1]
                decoder_input = decoder_input.view(decoder_input.size(0), -1)

                # 把decoder_input也转为嵌入
                decoder_input = self.embedder.embeddings(decoder_input)  # Embed token
                # 最终的形状[batch_size, 1, hidden_size]
                #decoder_input = embedder_output.last_hidden_state  # Extract last hidden state
                # 先用decoder上一时间步的隐藏状态和encoder所有隐藏状态计算当前context，
                # 再用上一时间步输入到decoder的token和这个context计算当前的隐藏状态和细胞状态
                # [batch_size, 1, hidden_size * 2]
                decoder_input = torch.cat((decoder_input, context), -1)
                # 形状为[batch_size, 1, hidden_size]
                decoder_input = self.input_projection(decoder_input)

                # LSTM Decoder
                # decoder_output形状为(batch_size, 1, hidden_size)
                decoder_output, (decoder_hidden, decoder_cell) = self.decoder(decoder_input,
                                                                              (decoder_hidden, decoder_cell))

                # Add output to list
                outputs.append(decoder_output)

            # shape: (batch_size, target_length, hidden_size)
            outputs = torch.cat(outputs, dim=1)
            # (target_length, batch_size, hidden_size)
            out = outputs.permute(1, 0, 2).contiguous()
            # 您可以使用以下代码来打印张量的形状：
            #print("Shape of 'out' after permute and contiguous: ", out.shape)
            # Shape of 'out' after permute and contiguous:  torch.Size([4, 256, 768])
            # dense的作用是调整每个batch每个target的token的hidden_state维度
            # 将经过线性层的输出通过激活函数tanh处理。tanh是一种常见的激活函数，它可以将输入值压缩到-1和1之间。
            # 使输出范围更加稳定，只改变每个hidden的值但不改变hidden的维度

            # 经过permute处理形状变为(batch_size, target_length, new_hidden_size)
            hidden_states = torch.tanh(self.dense(out)).permute([1, 0, 2]).contiguous()

            # 调整到词汇表尺寸
            # 形状为(batch_size, target_length, new_new_hidden_size)
            lm_logits = self.lm_head(hidden_states)

            # 创建一个布尔型张量，标识了计算损失时都应该考虑哪些tokens
            # target_mask形状为（batch_size，target_length）
            # [...]选择所有未指定的维度，这里只选择除了target_length外所有维度
            # target_length这个维度从[1:]第二个开始选择,因为第一个维度时起始符号
            # ne(0) 就是创建一个新的布尔型张量，该张量与 target_mask[..., 1:] 有相同的形状，其中的每个元素都表示 target_mask[..., 1:] 中对应元素是否不等于 0，[T,T,T,T,F,F,F,F]
            # view(-1)把（batch_size,target_length）变为（batch_size*target_length,）一维的
            # 因为像交叉熵函数只接受一维输入
            active_loss = target_mask[..., 1:].ne(0).view(-1) == 1

            # 将输出向左移动一位，也就是说，第n个位置的输出现在用来预测第n+1个位置的单词。
            shift_logits = lm_logits[..., :-1, :].contiguous()
            # 这行代码将目标ID向右移动一位，以与shift_logits对应。这样，第n个位置的shift_logits就对应着第n+1个位置的词。
            shift_labels = target_ids[..., 1:].contiguous()
            # Flatten the tokens
            # 这一行定义了损失函数为交叉熵损失（CrossEntropyLoss）。ignore_index=-1参数表示对标签值为-1的项不计算损失。
            loss_fct = nn.CrossEntropyLoss(ignore_index=-1)
            loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1))[active_loss],
                            shift_labels.view(-1)[active_loss])
            # 这一行将单个样本的损失，总损失（单个样本损失乘以损失位置的数量）和损失位置的数量封装成一个元组返回。
            outputs = loss, loss * active_loss.sum(), active_loss.sum()
            return outputs
        else:
            # Inference
            # 初始为(batch_size, sequence_length, hidden_size)
            # 调整后(sequence_length, batch_size, hidden_size)
            encoder_output = encoder_outputs.permute([1,0,2]).contiguous()
            preds = []
            zero = torch.cuda.LongTensor(1).fill_(0)
            # 循环batch_size次
            for i in range(source_ids.shape[0]):
                hidden_copy = hidden[:, i:i + 1]
                cell_copy = cell[:, i:i + 1]
                hidden_copy = hidden_copy.repeat(1, self.beam_size, 1)
                cell_copy = cell_copy.repeat(1, self.beam_size, 1)

                decoder_hidden = hidden_copy
                decoder_cell = cell_copy

                # 但现在每次只处理batch中的一个所以，context的形状为(source_length, 第i个, hidden_size)
                # context代表调整维度后的嵌入
                context = encoder_output[:, i:i + 1]
                # repeat 后形状变为(seq_length, beam_size, hidden_size)
                context = context.repeat(1, self.beam_size, 1)
                # context为((beam_size, sequence_length, hidden_size))
                context = context.permute(1, 0, 2).contiguous()

                # 所以context_mask为(第i个，source_length)
                context_mask = source_mask[i:i + 1, :]
                # (第i个, source_length)变为(bm_size, source_length)
                context_mask = context_mask.repeat(self.beam_size, 1)

                # Initialize the Beam object
                beam = Beam(self.beam_size, self.sos_id, self.eos_id)
                # 形状为[beam_size, 1]
                input_ids = beam.getCurrentState()

                # 生成的最大序列
                for _ in range(self.max_length):
                # for _ in range(self.max_length):
                    if beam.done():
                        break

                    # input_ids形状为[beam_size, 1]
                    # tgt形状为[beam_size, 1, embedding_dim]
                    tgt_embeddings = self.embedder.embeddings(input_ids)
                    #print("Shape of tgt_embeddings: ", tgt_embeddings.shape)
                    # Shape of tgt_embeddings:  torch.Size([2, 1, 768])

                    # Apply attention
                    context_layers = []
                    # 编码器如果是多层多向的需要多次提取
                    for j in range(hidden.size(0)):
                        # 此时decoder_hidden[j]为(beam_size, hidden_size)
                        # context为((beam_size, sequence_length, hidden_size))
                        # # attention_weights为[batch_size, 1, timestep]
                        #print("Shape of 'decoder_hidden[j]': ", decoder_hidden[j].shape)
                        #print("Shape of 'context': ", context.shape)
                        attention_weights = self.attention(decoder_hidden[j], context)
                        #print("Shape of 'attention_weights': ", attention_weights.shape)
                        # Shape of 'attention_weights':  torch.Size([2, 1, 16])

                        # 形状为(beam_size, 1, hidden_size)
                        context_layer = attention_weights.bmm(context)
                        #print("Shape of 'context_layer': ", context_layer.shape)
                        # Shape of 'context_layer':  torch.Size([2, 1, 768])
                        # 每层获取的都添加在这里
                        context_layers.append(context_layer)
                    # 将所有LSTM层的上下文向量合并在一起
                    # 形状为[beam_size, 1, hidden_size]
                    new_context = torch.mean(torch.stack(context_layers),dim=0)

                    # 后续可尝试用下面代码取代上述代码求new_context
                    # layer_weights = torch.nn.functional.softmax(self.layer_weights, dim=0)
                    # new_context = torch.sum(layer_weights * torch.stack(context_layers), dim=0)

                    #print("Shape of 'new_context': ", new_context.shape)
                    # Shape of 'new_context':  torch.Size([2, 1, 768])

                    # tgt形状为[beam_size, 1, embedding_dim]
                    # new_context形状为[beam_size, 1, hidden_size]
                    # 得到的decoder_input为[beam_size, 1, hidden_size * 2]
                    # Get the last generated word's embedding
                    last_word_embeddings = tgt_embeddings[:, -1:, :]
                    # Concatenate the new_context and last_word_embeddings
                    decoder_input = torch.cat((last_word_embeddings, new_context), -1)
                    # 形状为[beam_size, 1, hidden_size]
                    decoder_input = self.input_projection(decoder_input)

                    # LSTM Decoder
                    # decoder_output形状为(beam_size, 1, hidden_size)
                    decoder_output, (decoder_hidden, decoder_cell) = self.decoder(decoder_input,(decoder_hidden, decoder_cell))
                    decoder_output = torch.tanh(self.dense(decoder_output))
                    hidden_states = decoder_output.permute([1, 0, 2]).contiguous()[:, -1, :]

                    out = self.lsm(self.lm_head(hidden_states)).data
                    #print("Shape of 'out': ", out.shape)
                    beam.advance(out)

                    # 这两行代码的目的是更新模型的输入,以便在下一步能够基于当前选择的beam和词汇进行预测
                    input_ids.data.copy_(input_ids.data.index_select(0, beam.getCurrentOrigin()))
                    input_ids = torch.cat((input_ids, beam.getCurrentState()), -1)
                    # 获取beam search的结果，并进行处理，然后添加到preds列表中
                hyp = beam.getHyp(beam.getFinal())
                pred = beam.buildTargetTokens(hyp)[:self.beam_size]
                pred = [torch.cat([x.view(-1) for x in p] + [zero] * (self.max_length - len(p))).view(1, -1) for p in
                        pred]
                preds.append(torch.cat(pred, 0).unsqueeze(0))
            # 这里的preds是一个列表，列表中每个元素是一个tensor，这些tensor代表了模型对不同输入的预测结果。因为模型是分批次处理输入的，所以每个tensor对应一个批次的结果。
            # torch.cat(preds, 0)的作用就是把这些tensor按照第0维（通常是批次维度）拼接在一起，得到一个新的tensor。这样，新的tensor就包含了模型对所有输入的预测结果
            preds = torch.cat(preds, 0)
            return preds


class Beam(object):
    def __init__(self, size, sos, eos):
        self.size = size
        self.tt = torch.cuda
        # The score for each translation on the beam.
        self.scores = self.tt.FloatTensor(size).zero_()

        # The backpointers at each time-step.
        self.prevKs = []
        # The outputs at each time-step.
        self.nextYs = [self.tt.LongTensor(size)
                       .fill_(0)]
        self.nextYs[0][0] = sos
        # Has EOS topped the beam yet.
        self._eos = eos
        self.eosTop = False
        # Time and k pair for finished.
        self.finished = []

    def getCurrentState(self):
        "Get the outputs for the current timestep."
        batch = self.tt.LongTensor(self.nextYs[-1]).view(-1, 1)
        return batch

    def getCurrentOrigin(self):
        "Get the backpointers for the current timestep."
        return self.prevKs[-1]

    def advance(self, wordLk):
        """
        Given prob over words for every last beam `wordLk` and attention
        `attnOut`: Compute and update the beam search.

        Parameters:

        * `wordLk`- probs of advancing from the last step (K x words)
        * `attnOut`- attention at the last step

        Returns: True if beam search is complete.
        """
        numWords = wordLk.size(1)

        # Sum the previous scores.
        if len(self.prevKs) > 0:
            beamLk = self.scores.unsqueeze(1) + wordLk  # Changed this line

            # Don't let EOS have children.
            for i in range(self.nextYs[-1].size(0)):
                if self.nextYs[-1][i] == self._eos:
                    beamLk[i] = -1e20
        else:
            beamLk = wordLk[0]
        flatBeamLk = beamLk.view(-1)
        bestScores, bestScoresId = flatBeamLk.topk(self.size, 0, True, True)

        self.scores = bestScores

        # bestScoresId is flattened beam x word array, so calculate which
        # word and beam each score came from
        prevK = bestScoresId // numWords
        self.prevKs.append(prevK)
        self.nextYs.append((bestScoresId - prevK * numWords))

        for i in range(self.nextYs[-1].size(0)):
            if self.nextYs[-1][i] == self._eos:
                s = self.scores[i]
                self.finished.append((s, len(self.nextYs) - 1, i))

        # End condition is when top-of-beam is EOS and no global score.
        if self.nextYs[-1][0] == self._eos:
            self.eosTop = True

    # def advance(self, wordLk):
    #     """
    #     Given prob over words for every last beam `wordLk` and attention
    #     `attnOut`: Compute and update the beam search.
    #
    #     Parameters:
    #
    #     * `wordLk`- probs of advancing from the last step (K x words)
    #     * `attnOut`- attention at the last step
    #
    #     Returns: True if beam search is complete.
    #     """
    #     numWords = wordLk.size(1)
    #
    #     # Sum the previous scores.
    #
    #     if len(self.prevKs) > 0:
    #         beamLk = wordLk + self.scores.unsqueeze(1).expand_as(wordLk)
    #
    #         # Don't let EOS have children.
    #         for i in range(self.nextYs[-1].size(0)):
    #             if self.nextYs[-1][i] == self._eos:
    #                 beamLk[i] = -1e20
    #     else:
    #         beamLk = wordLk[0]
    #     flatBeamLk = beamLk.view(-1)
    #     bestScores, bestScoresId = flatBeamLk.topk(self.size, 0, True, True)
    #
    #     self.scores = bestScores
    #
    #     # bestScoresId is flattened beam x word array, so calculate which
    #     # word and beam each score came from
    #     prevK = bestScoresId // numWords
    #     self.prevKs.append(prevK)
    #     self.nextYs.append((bestScoresId - prevK * numWords))
    #
    #     for i in range(self.nextYs[-1].size(0)):
    #         if self.nextYs[-1][i] == self._eos:
    #             s = self.scores[i]
    #             self.finished.append((s, len(self.nextYs) - 1, i))
    #
    #     # End condition is when top-of-beam is EOS and no global score.
    #     if self.nextYs[-1][0] == self._eos:
    #         self.eosTop = True


    def done(self):
        return self.eosTop and len(self.finished) >= self.size

    def getFinal(self):
        if len(self.finished) == 0:
            self.finished.append((self.scores[0], len(self.nextYs) - 1, 0))
        self.finished.sort(key=lambda a: -a[0])
        if len(self.finished) != self.size:
            unfinished = []
            for i in range(self.nextYs[-1].size(0)):
                if self.nextYs[-1][i] != self._eos:
                    s = self.scores[i]
                    unfinished.append((s, len(self.nextYs) - 1, i))
            unfinished.sort(key=lambda a: -a[0])
            self.finished += unfinished[:self.size - len(self.finished)]
        return self.finished[:self.size]

    def getHyp(self, beam_res):
        """
        Walk back to construct the full hypothesis.
        """
        hyps = []
        for _, timestep, k in beam_res:
            hyp = []
            for j in range(len(self.prevKs[:timestep]) - 1, -1, -1):
                hyp.append(self.nextYs[j + 1][k])
                k = self.prevKs[j][k]
            hyps.append(hyp[::-1])
        return hyps

    def buildTargetTokens(self, preds):
        sentence = []
        for pred in preds:
            tokens = []
            for tok in pred:
                if tok == self._eos:
                    break
                tokens.append(tok)
            sentence.append(tokens)
        return sentence



